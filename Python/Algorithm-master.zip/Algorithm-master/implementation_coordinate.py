# input 1 : 정사각형 공간의 크기 입력
# input 2 : U,D,L,R이 공백으로 구분되어 이동 경로를 입력
# 범위를 벗어나는 이동경로는 무시
# output : 최종 도착 좌표를 공백으로 구분하여 출력

n=int(input())
r=input().split()
x,y=1